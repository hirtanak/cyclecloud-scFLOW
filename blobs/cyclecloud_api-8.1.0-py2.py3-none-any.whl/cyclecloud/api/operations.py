# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import copy as _copy
import json as _json

from cyclecloud import model as _model


_TAG="Operations"

class _RequestContext(object):
    def __init__(self):
        self.url = None
        self.host = None
        self.path = None
        self.tag = None
        self.operation = None


def list(session, request_id=None):
    """
    No description available
    Parameters:
    request_id: string, The request ID for the operation. If this is given, the list will only have 0 or 1 element in it., Optional

    Returns: (status, data)
    (200, array[])
    (400, async_url)
    (404, async_url)
    """
    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "list"

    _path_parameters = {}
    _request_context.path = "/operations/".format(**_path_parameters)

    _query = {}
    if request_id:
        _query['request_id'] = request_id

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'array', _model.OperationStatus.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_status(session, id):
    """
    No description available
    Parameters:
    id: string, The operation ID, Required

    Returns: (status, data)
    (200, OperationStatus)
    (404, async_url)
    """
    if not id:
        raise ValueError('id is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "getStatus"

    _path_parameters = {}
    _path_parameters["id"] = id
    _request_context.path = "/operations/{id}".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.OperationStatus.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response



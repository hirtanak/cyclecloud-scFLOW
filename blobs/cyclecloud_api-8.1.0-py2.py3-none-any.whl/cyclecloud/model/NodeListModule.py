# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodeList as _NodeList


    def json_decode(json_string):
        return _NodeList.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeList.from_dict(dict_obj)


    def NodeList(**kwargs):
        obj = _NodeList()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeList.json_decode = _NodeList.json_decode
    NodeList.from_dict = _NodeList.from_dict


else:
    from .OperationStatusModule import OperationStatus


    def json_decode(json_string):
        return NodeList.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeList.from_dict(dict_obj)


    class NodeList(object):
        """
        Results of a node search
        nodes: [object], The nodes returned, Required
        operation: OperationStatus, The status of this node operation, Optional
        """

        def __init__(self, **kwargs):
            self.nodes = kwargs.get('nodes')
            self.operation = kwargs.get('operation')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.nodes is None:
                raise ValueError('Property NodeList.nodes is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.nodes is not None:
                dict_obj["nodes"] = [v for v in self.nodes]

            if self.operation is not None:
                dict_obj["operation"] = self.operation.to_dict()

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeList()

            value = dict_obj.get('nodes')
            if value is not None:
                obj.nodes = []
                for item in value:
                    obj.nodes.append(item)

            value = dict_obj.get('operation')
            if value is not None:
                obj.operation = OperationStatus.from_dict(value)

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeList.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def nodes(self):
            """
            nodes: [object], The nodes returned, Required
            """
            return self._nodes

        @nodes.setter
        def nodes(self, value):
            """
            nodes: [object], The nodes returned, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeList.nodes.')
            self._nodes = value

        @property
        def operation(self):
            """
            operation: OperationStatus, The status of this node operation, Optional
            """
            return self._operation

        @operation.setter
        def operation(self, value):
            """
            operation: OperationStatus, The status of this node operation, Optional
            """
            if value:
                if isinstance(value, dict):
                    value = OperationStatus.from_dict(value)
                if not isinstance(value, OperationStatus):
                    raise TypeError('Value for NodeList.operation must be OperationStatus or dict')
            self._operation = value


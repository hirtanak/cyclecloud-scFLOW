# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterNodearrayStatus as _ClusterNodearrayStatus


    def json_decode(json_string):
        return _ClusterNodearrayStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterNodearrayStatus.from_dict(dict_obj)


    def ClusterNodearrayStatus(**kwargs):
        obj = _ClusterNodearrayStatus()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterNodearrayStatus.json_decode = _ClusterNodearrayStatus.json_decode
    ClusterNodearrayStatus.from_dict = _ClusterNodearrayStatus.from_dict


else:
    from .NodearrayBucketStatusModule import NodearrayBucketStatus


    def json_decode(json_string):
        return ClusterNodearrayStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterNodearrayStatus.from_dict(dict_obj)


    class ClusterNodearrayStatus(object):
        """
        
        buckets: [NodearrayBucketStatus], Each bucket of allocation for this nodearray. The "core count" settings are always a multiple of the core count for this bucket.
, Required
        max_core_count: integer, The maximum number of cores that may be in this nodearray, Required
        max_count: integer, The maximum number of nodes that may be in this nodearray, Required
        name: string, The nodearray this is describing, Required
        nodearray: object, A node record, Required
        """

        def __init__(self, **kwargs):
            self.buckets = kwargs.get('buckets')
            self.max_core_count = kwargs.get('max_core_count')
            self.max_count = kwargs.get('max_count')
            self.name = kwargs.get('name')
            self.nodearray = kwargs.get('nodearray')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.buckets is None:
                raise ValueError('Property ClusterNodearrayStatus.buckets is required.')
            if self.max_core_count is None:
                raise ValueError('Property ClusterNodearrayStatus.max_core_count is required.')
            if self.max_count is None:
                raise ValueError('Property ClusterNodearrayStatus.max_count is required.')
            if self.name is None:
                raise ValueError('Property ClusterNodearrayStatus.name is required.')
            if self.nodearray is None:
                raise ValueError('Property ClusterNodearrayStatus.nodearray is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.buckets is not None:
                dict_obj["buckets"] = [v.to_dict() for v in self.buckets]

            if self.max_core_count is not None:
                dict_obj["maxCoreCount"] = self.max_core_count

            if self.max_count is not None:
                dict_obj["maxCount"] = self.max_count

            if self.name is not None:
                dict_obj["name"] = self.name

            if self.nodearray is not None:
                dict_obj["nodearray"] = self.nodearray

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterNodearrayStatus()

            value = dict_obj.get('buckets')
            if value is not None:
                obj.buckets = []
                for item in value:
                    obj.buckets.append(NodearrayBucketStatus.from_dict(item))

            value = dict_obj.get('maxcorecount')
            if value is not None:
                obj.max_core_count = value

            value = dict_obj.get('maxcount')
            if value is not None:
                obj.max_count = value

            value = dict_obj.get('name')
            if value is not None:
                obj.name = value

            value = dict_obj.get('nodearray')
            if value is not None:
                obj.nodearray = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterNodearrayStatus.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def buckets(self):
            """
            buckets: [NodearrayBucketStatus], Each bucket of allocation for this nodearray. The "core count" settings are always a multiple of the core count for this bucket.
, Required
            """
            return self._buckets

        @buckets.setter
        def buckets(self, value):
            """
            buckets: [NodearrayBucketStatus], Each bucket of allocation for this nodearray. The "core count" settings are always a multiple of the core count for this bucket.
, Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterNodearrayStatus.buckets.')
            self._buckets = value

        @property
        def max_core_count(self):
            """
            max_core_count: integer, The maximum number of cores that may be in this nodearray, Required
            """
            return self._max_core_count

        @max_core_count.setter
        def max_core_count(self, value):
            """
            max_core_count: integer, The maximum number of cores that may be in this nodearray, Required
            """
            self._max_core_count = value

        @property
        def max_count(self):
            """
            max_count: integer, The maximum number of nodes that may be in this nodearray, Required
            """
            return self._max_count

        @max_count.setter
        def max_count(self, value):
            """
            max_count: integer, The maximum number of nodes that may be in this nodearray, Required
            """
            self._max_count = value

        @property
        def name(self):
            """
            name: string, The nodearray this is describing, Required
            """
            return self._name

        @name.setter
        def name(self, value):
            """
            name: string, The nodearray this is describing, Required
            """
            self._name = value

        @property
        def nodearray(self):
            """
            nodearray: object, A node record, Required
            """
            return self._nodearray

        @nodearray.setter
        def nodearray(self, value):
            """
            nodearray: object, A node record, Required
            """
            self._nodearray = value


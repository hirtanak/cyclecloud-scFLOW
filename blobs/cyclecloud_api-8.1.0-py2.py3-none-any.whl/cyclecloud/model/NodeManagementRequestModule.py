# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodeManagementRequest as _NodeManagementRequest


    def json_decode(json_string):
        return _NodeManagementRequest.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeManagementRequest.from_dict(dict_obj)


    def NodeManagementRequest(**kwargs):
        obj = _NodeManagementRequest()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeManagementRequest.json_decode = _NodeManagementRequest.json_decode
    NodeManagementRequest.from_dict = _NodeManagementRequest.from_dict


else:


    def json_decode(json_string):
        return NodeManagementRequest.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeManagementRequest.from_dict(dict_obj)


    class NodeManagementRequest(object):
        """
        Specifies how to perform actions on nodes in a cluster. There are multiple ways to specify nodes, and if more than one way is included, it is treated as a union.

        filter: string, A filter expression that matches nodes. Note that strings in the expression must be quoted properly., Optional
        hostnames: [string], A list of short hostnames (with no domain) to manage, Optional
        ids: [string], A list of node ids to manage, Optional
        ip_addresses: [string], A list of IP addresses to manage, Optional
        names: [string], A list of node names to manage, Optional
        request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
        """

        def __init__(self, **kwargs):
            self.filter = kwargs.get('filter')
            self.hostnames = kwargs.get('hostnames')
            self.ids = kwargs.get('ids')
            self.ip_addresses = kwargs.get('ip_addresses')
            self.names = kwargs.get('names')
            self.request_id = kwargs.get('request_id')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            pass

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.filter is not None:
                dict_obj["filter"] = self.filter

            if self.hostnames is not None:
                dict_obj["hostnames"] = [v for v in self.hostnames]

            if self.ids is not None:
                dict_obj["ids"] = [v for v in self.ids]

            if self.ip_addresses is not None:
                dict_obj["ip_addresses"] = [v for v in self.ip_addresses]

            if self.names is not None:
                dict_obj["names"] = [v for v in self.names]

            if self.request_id is not None:
                dict_obj["requestId"] = self.request_id

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeManagementRequest()

            value = dict_obj.get('filter')
            if value is not None:
                obj.filter = value

            value = dict_obj.get('hostnames')
            if value is not None:
                obj.hostnames = []
                for item in value:
                    obj.hostnames.append(item)

            value = dict_obj.get('ids')
            if value is not None:
                obj.ids = []
                for item in value:
                    obj.ids.append(item)

            value = dict_obj.get('ip_addresses')
            if value is not None:
                obj.ip_addresses = []
                for item in value:
                    obj.ip_addresses.append(item)

            value = dict_obj.get('names')
            if value is not None:
                obj.names = []
                for item in value:
                    obj.names.append(item)

            value = dict_obj.get('requestid')
            if value is not None:
                obj.request_id = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeManagementRequest.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def filter(self):
            """
            filter: string, A filter expression that matches nodes. Note that strings in the expression must be quoted properly., Optional
            """
            return self._filter

        @filter.setter
        def filter(self, value):
            """
            filter: string, A filter expression that matches nodes. Note that strings in the expression must be quoted properly., Optional
            """
            self._filter = value

        @property
        def hostnames(self):
            """
            hostnames: [string], A list of short hostnames (with no domain) to manage, Optional
            """
            return self._hostnames

        @hostnames.setter
        def hostnames(self, value):
            """
            hostnames: [string], A list of short hostnames (with no domain) to manage, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeManagementRequest.hostnames.')
            self._hostnames = value

        @property
        def ids(self):
            """
            ids: [string], A list of node ids to manage, Optional
            """
            return self._ids

        @ids.setter
        def ids(self, value):
            """
            ids: [string], A list of node ids to manage, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeManagementRequest.ids.')
            self._ids = value

        @property
        def ip_addresses(self):
            """
            ip_addresses: [string], A list of IP addresses to manage, Optional
            """
            return self._ip_addresses

        @ip_addresses.setter
        def ip_addresses(self, value):
            """
            ip_addresses: [string], A list of IP addresses to manage, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeManagementRequest.ip_addresses.')
            self._ip_addresses = value

        @property
        def names(self):
            """
            names: [string], A list of node names to manage, Optional
            """
            return self._names

        @names.setter
        def names(self, value):
            """
            names: [string], A list of node names to manage, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for NodeManagementRequest.names.')
            self._names = value

        @property
        def request_id(self):
            """
            request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
            """
            return self._request_id

        @request_id.setter
        def request_id(self, value):
            """
            request_id: string, Optional user-supplied unique token to prevent duplicate operations in case of network communication errors.  If this is included and matches an earlier request id, the server ignores this request and returns a 409 error.
, Optional
            """
            self._request_id = value


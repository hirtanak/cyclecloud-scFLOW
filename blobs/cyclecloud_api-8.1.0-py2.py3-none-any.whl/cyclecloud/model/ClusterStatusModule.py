# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import ClusterStatus as _ClusterStatus


    def json_decode(json_string):
        return _ClusterStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return _ClusterStatus.from_dict(dict_obj)


    def ClusterStatus(**kwargs):
        obj = _ClusterStatus()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    ClusterStatus.json_decode = _ClusterStatus.json_decode
    ClusterStatus.from_dict = _ClusterStatus.from_dict


else:
    from .ClusterNodearrayStatusModule import ClusterNodearrayStatus


    def json_decode(json_string):
        return ClusterStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return ClusterStatus.from_dict(dict_obj)


    class ClusterStatus(object):
        """
        Status of the cluster
        max_core_count: integer, The maximum number of cores that may be added to this cluster, Required
        max_count: integer, The maximum number of nodes that may be added to this cluster, Required
        nodearrays: [ClusterNodearrayStatus], , Required
        nodes: [object], An optional list of nodes in this cluster, only included if nodes=true is in the query, Optional
        state: string, The current state of the cluster, if it has been started at least once, Optional
        target_state: string, The desired state of the cluster (eg Started or Terminated), Optional
        """

        def __init__(self, **kwargs):
            self.max_core_count = kwargs.get('max_core_count')
            self.max_count = kwargs.get('max_count')
            self.nodearrays = kwargs.get('nodearrays')
            self.nodes = kwargs.get('nodes')
            self.state = kwargs.get('state')
            self.target_state = kwargs.get('target_state')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.max_core_count is None:
                raise ValueError('Property ClusterStatus.max_core_count is required.')
            if self.max_count is None:
                raise ValueError('Property ClusterStatus.max_count is required.')
            if self.nodearrays is None:
                raise ValueError('Property ClusterStatus.nodearrays is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.max_core_count is not None:
                dict_obj["maxCoreCount"] = self.max_core_count

            if self.max_count is not None:
                dict_obj["maxCount"] = self.max_count

            if self.nodearrays is not None:
                dict_obj["nodearrays"] = [v.to_dict() for v in self.nodearrays]

            if self.nodes is not None:
                dict_obj["nodes"] = [v for v in self.nodes]

            if self.state is not None:
                dict_obj["state"] = self.state

            if self.target_state is not None:
                dict_obj["targetState"] = self.target_state

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = ClusterStatus()

            value = dict_obj.get('maxcorecount')
            if value is not None:
                obj.max_core_count = value

            value = dict_obj.get('maxcount')
            if value is not None:
                obj.max_count = value

            value = dict_obj.get('nodearrays')
            if value is not None:
                obj.nodearrays = []
                for item in value:
                    obj.nodearrays.append(ClusterNodearrayStatus.from_dict(item))

            value = dict_obj.get('nodes')
            if value is not None:
                obj.nodes = []
                for item in value:
                    obj.nodes.append(item)

            value = dict_obj.get('state')
            if value is not None:
                obj.state = value

            value = dict_obj.get('targetstate')
            if value is not None:
                obj.target_state = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return ClusterStatus.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def max_core_count(self):
            """
            max_core_count: integer, The maximum number of cores that may be added to this cluster, Required
            """
            return self._max_core_count

        @max_core_count.setter
        def max_core_count(self, value):
            """
            max_core_count: integer, The maximum number of cores that may be added to this cluster, Required
            """
            self._max_core_count = value

        @property
        def max_count(self):
            """
            max_count: integer, The maximum number of nodes that may be added to this cluster, Required
            """
            return self._max_count

        @max_count.setter
        def max_count(self, value):
            """
            max_count: integer, The maximum number of nodes that may be added to this cluster, Required
            """
            self._max_count = value

        @property
        def nodearrays(self):
            """
            nodearrays: [ClusterNodearrayStatus], , Required
            """
            return self._nodearrays

        @nodearrays.setter
        def nodearrays(self, value):
            """
            nodearrays: [ClusterNodearrayStatus], , Required
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterStatus.nodearrays.')
            self._nodearrays = value

        @property
        def nodes(self):
            """
            nodes: [object], An optional list of nodes in this cluster, only included if nodes=true is in the query, Optional
            """
            return self._nodes

        @nodes.setter
        def nodes(self, value):
            """
            nodes: [object], An optional list of nodes in this cluster, only included if nodes=true is in the query, Optional
            """
            if value:
                if type(value) is not list:
                    raise TypeError('Must supply a list for ClusterStatus.nodes.')
            self._nodes = value

        @property
        def state(self):
            """
            state: string, The current state of the cluster, if it has been started at least once, Optional
            """
            return self._state

        @state.setter
        def state(self, value):
            """
            state: string, The current state of the cluster, if it has been started at least once, Optional
            """
            self._state = value

        @property
        def target_state(self):
            """
            target_state: string, The desired state of the cluster (eg Started or Terminated), Optional
            """
            return self._target_state

        @target_state.setter
        def target_state(self, value):
            """
            target_state: string, The desired state of the cluster (eg Started or Terminated), Optional
            """
            self._target_state = value


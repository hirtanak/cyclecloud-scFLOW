# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import PlacementGroupStatus as _PlacementGroupStatus


    def json_decode(json_string):
        return _PlacementGroupStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return _PlacementGroupStatus.from_dict(dict_obj)


    def PlacementGroupStatus(**kwargs):
        obj = _PlacementGroupStatus()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    PlacementGroupStatus.json_decode = _PlacementGroupStatus.json_decode
    PlacementGroupStatus.from_dict = _PlacementGroupStatus.from_dict


else:


    def json_decode(json_string):
        return PlacementGroupStatus.json_decode(json_string)


    def from_dict(dict_obj):
        return PlacementGroupStatus.from_dict(dict_obj)


    class PlacementGroupStatus(object):
        """
        Information about each placement group

        active_core_count: integer, How many cores are in this scaleset, Required
        active_count: integer, How many nodes are in this scaleset, Required
        name: string, The unique identifier of this placement group, Required
        """

        def __init__(self, **kwargs):
            self.active_core_count = kwargs.get('active_core_count')
            self.active_count = kwargs.get('active_count')
            self.name = kwargs.get('name')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.active_core_count is None:
                raise ValueError('Property PlacementGroupStatus.active_core_count is required.')
            if self.active_count is None:
                raise ValueError('Property PlacementGroupStatus.active_count is required.')
            if self.name is None:
                raise ValueError('Property PlacementGroupStatus.name is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.active_core_count is not None:
                dict_obj["activeCoreCount"] = self.active_core_count

            if self.active_count is not None:
                dict_obj["activeCount"] = self.active_count

            if self.name is not None:
                dict_obj["name"] = self.name

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = PlacementGroupStatus()

            value = dict_obj.get('activecorecount')
            if value is not None:
                obj.active_core_count = value

            value = dict_obj.get('activecount')
            if value is not None:
                obj.active_count = value

            value = dict_obj.get('name')
            if value is not None:
                obj.name = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return PlacementGroupStatus.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def active_core_count(self):
            """
            active_core_count: integer, How many cores are in this scaleset, Required
            """
            return self._active_core_count

        @active_core_count.setter
        def active_core_count(self, value):
            """
            active_core_count: integer, How many cores are in this scaleset, Required
            """
            self._active_core_count = value

        @property
        def active_count(self):
            """
            active_count: integer, How many nodes are in this scaleset, Required
            """
            return self._active_count

        @active_count.setter
        def active_count(self, value):
            """
            active_count: integer, How many nodes are in this scaleset, Required
            """
            self._active_count = value

        @property
        def name(self):
            """
            name: string, The unique identifier of this placement group, Required
            """
            return self._name

        @name.setter
        def name(self, value):
            """
            name: string, The unique identifier of this placement group, Required
            """
            self._name = value


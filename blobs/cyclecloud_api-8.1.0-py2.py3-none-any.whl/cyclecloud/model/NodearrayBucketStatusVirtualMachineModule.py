# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodearrayBucketStatusVirtualMachine as _NodearrayBucketStatusVirtualMachine


    def json_decode(json_string):
        return _NodearrayBucketStatusVirtualMachine.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)


    def NodearrayBucketStatusVirtualMachine(**kwargs):
        obj = _NodearrayBucketStatusVirtualMachine()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodearrayBucketStatusVirtualMachine.json_decode = _NodearrayBucketStatusVirtualMachine.json_decode
    NodearrayBucketStatusVirtualMachine.from_dict = _NodearrayBucketStatusVirtualMachine.from_dict


else:


    def json_decode(json_string):
        return NodearrayBucketStatusVirtualMachine.json_decode(json_string)


    def from_dict(dict_obj):
        return NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)


    class NodearrayBucketStatusVirtualMachine(object):
        """
        The properties of the virtual machines launched from this bucket
        gpu_count: integer, The number of GPUs this machine type has, Required
        infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
        memory: float, The RAM in this virtual machine, in GB, Required
        pcpu_count: integer, The number of physical CPUs this machine type has, Required
        vcpu_count: integer, The number of virtual CPUs this machine type has, Required
        """

        def __init__(self, **kwargs):
            self.gpu_count = kwargs.get('gpu_count')
            self.infiniband = kwargs.get('infiniband')
            self.memory = kwargs.get('memory')
            self.pcpu_count = kwargs.get('pcpu_count')
            self.vcpu_count = kwargs.get('vcpu_count')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            if self.gpu_count is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.gpu_count is required.')
            if self.infiniband is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.infiniband is required.')
            if self.memory is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.memory is required.')
            if self.pcpu_count is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.pcpu_count is required.')
            if self.vcpu_count is None:
                raise ValueError('Property NodearrayBucketStatusVirtualMachine.vcpu_count is required.')

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.gpu_count is not None:
                dict_obj["gpuCount"] = self.gpu_count

            if self.infiniband is not None:
                dict_obj["infiniband"] = self.infiniband

            if self.memory is not None:
                dict_obj["memory"] = self.memory

            if self.pcpu_count is not None:
                dict_obj["pcpuCount"] = self.pcpu_count

            if self.vcpu_count is not None:
                dict_obj["vcpuCount"] = self.vcpu_count

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodearrayBucketStatusVirtualMachine()

            value = dict_obj.get('gpucount')
            if value is not None:
                obj.gpu_count = value

            value = dict_obj.get('infiniband')
            if value is not None:
                obj.infiniband = value

            value = dict_obj.get('memory')
            if value is not None:
                obj.memory = value

            value = dict_obj.get('pcpucount')
            if value is not None:
                obj.pcpu_count = value

            value = dict_obj.get('vcpucount')
            if value is not None:
                obj.vcpu_count = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodearrayBucketStatusVirtualMachine.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def gpu_count(self):
            """
            gpu_count: integer, The number of GPUs this machine type has, Required
            """
            return self._gpu_count

        @gpu_count.setter
        def gpu_count(self, value):
            """
            gpu_count: integer, The number of GPUs this machine type has, Required
            """
            self._gpu_count = value

        @property
        def infiniband(self):
            """
            infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
            """
            return self._infiniband

        @infiniband.setter
        def infiniband(self, value):
            """
            infiniband: boolean, If this virtual machine supports InfiniBand connectivity, Required
            """
            self._infiniband = value

        @property
        def memory(self):
            """
            memory: float, The RAM in this virtual machine, in GB, Required
            """
            return self._memory

        @memory.setter
        def memory(self, value):
            """
            memory: float, The RAM in this virtual machine, in GB, Required
            """
            self._memory = value

        @property
        def pcpu_count(self):
            """
            pcpu_count: integer, The number of physical CPUs this machine type has, Required
            """
            return self._pcpu_count

        @pcpu_count.setter
        def pcpu_count(self, value):
            """
            pcpu_count: integer, The number of physical CPUs this machine type has, Required
            """
            self._pcpu_count = value

        @property
        def vcpu_count(self):
            """
            vcpu_count: integer, The number of virtual CPUs this machine type has, Required
            """
            return self._vcpu_count

        @vcpu_count.setter
        def vcpu_count(self, value):
            """
            vcpu_count: integer, The number of virtual CPUs this machine type has, Required
            """
            self._vcpu_count = value


__version__ = "8.1.0-SNAPSHOT"


def _append_build_number():
    import os

    build_number = None

    try:
        build_number_file = os.path.join(os.path.dirname(__file__), 'BUILD_NUMBER')

        if os.path.exists(build_number_file):
            with open(build_number_file, 'r') as f:
                build_number = f.read().strip()
    except:
        pass

    if build_number:
        global __version__
        __version__ = __version__.replace("-SNAPSHOT", "-%s" % build_number)


_append_build_number()
